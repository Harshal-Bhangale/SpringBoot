package com.assignment.bookreview.bookreviewApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookreviewAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookreviewAppApplication.class, args);
	}

}
