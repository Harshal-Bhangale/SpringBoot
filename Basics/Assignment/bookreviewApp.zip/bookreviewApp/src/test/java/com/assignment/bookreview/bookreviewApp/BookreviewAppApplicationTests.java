package com.assignment.bookreview.bookreviewApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookreviewAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
